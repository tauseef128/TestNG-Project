package com.bw.qa.exception;

public class FrameworkException extends RuntimeException {
    public FrameworkException(String mesg){
        super(mesg);
    }
}
