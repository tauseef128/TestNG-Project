package com.bw.qa.constants;

public class AppConstants {
    public static final int SHORT_DEFAULT_WAIT = 5;
    public static final int MEDIUM_DEFAULT_WAIT = 10;
    public static final int LONG_DEFAULT_WAIT = 15;
    public static final int POLLING_DEFAULT_WAIT = 2;

}
