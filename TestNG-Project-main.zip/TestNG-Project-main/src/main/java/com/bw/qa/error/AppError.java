package com.bw.qa.error;

public class AppError {
}
